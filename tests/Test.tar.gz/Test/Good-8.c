// Program to exercise the array feature implemented
#include<stdio.h>
void main()
{
int a[5]={1,2,3,4,5};
int c=0,d;
for(int i=0;i<5;i+)
	c += a[i];
printf(" sum is  %d  && random value is %d",c,d);
}
