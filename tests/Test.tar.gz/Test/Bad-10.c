//  To verify the declaration of variable
#include<stdio.h>
void main()
{
int int,float;
}
