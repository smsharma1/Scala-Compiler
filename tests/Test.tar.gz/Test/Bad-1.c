//semicolon after structure declaration
#include<stdio.h>
Struct node
{
int a;
int b;
}
int main()
{
    return 0;
}
