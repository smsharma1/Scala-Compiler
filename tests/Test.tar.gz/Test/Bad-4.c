//Bad test case - invalid identifier
#include<stdio.h>
void main(){
	int @a = 	55 	;
	printf("%d", a);
}
