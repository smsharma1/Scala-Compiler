//Error before main()
#icnlude <iostream>
int main()
{
   printf(“include misspelled”);
}
