//To check if an expression is syntactically correct or not:
#include<stdio.h>
void main() {
	int a = 0;
	++a++;
}
