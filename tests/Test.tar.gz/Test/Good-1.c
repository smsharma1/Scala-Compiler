//Good test case where
#include<stdio.h>
void main(){
	int a = 	55 	;
	char name[] = "Double quote (\") is escaped";
	printf("%s", name);
}
