//To check the structure of output statements:
#include<stdio.h>
void main() {
	int x = 10;
	printf( x);
}
