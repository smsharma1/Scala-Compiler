//Good test case to test multiple line string.
#include<stdio.h>
void main(){
	char name[] = "I am in "
                        	" more than"
                        	"line.";
	printf("%s", name);
}
