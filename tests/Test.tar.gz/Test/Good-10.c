//To check while loop structure:
#include<stdio.h>
void main(){
	int x = 0;
	while(x++);
}
