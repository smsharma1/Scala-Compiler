//Bad array initialization
#include<stdio.h>
void main(){
	//invalid array initialization
	int a[] = 1;
}
