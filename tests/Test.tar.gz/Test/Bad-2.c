//Bad test case - Keyword is used as a identifier.
#include<stdio.h>
void main(){
	char *name[3];
	char if;
	printf("if is a keyword, it can't be an identifier");
}
