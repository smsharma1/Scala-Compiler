// Expression inside the printf function
#include<stdio.h>
void main()
{
int a,b;
scanf("%d %d",&a,&b);
printf("%d",a+b);
}
