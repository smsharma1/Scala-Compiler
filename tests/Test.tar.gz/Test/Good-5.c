//Good test case for Expression parsing
#include<stdio.h>
void main(){
    int a = 1;
    int b = 2;
    int *p = &a;

    int c = a+++b;
int x = 23, y, z  = 23;
    x = y = z = x == z;
y = *p*b++**p;
}
