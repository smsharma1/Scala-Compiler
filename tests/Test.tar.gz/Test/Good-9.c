// To check the the structure of for loop:
#include<stdio.h>
void main() {
	int x = 0;
	for(;;) {
		if(x == 2);
		x++;
	}
}
