// case - sensitivity of language
#include<stdio.h>
void main()
{
IF(1<=3)
{
printf("It will always run");
}
