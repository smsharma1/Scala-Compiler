// This test case is to test nested commenting // By- Nishit
#include<stdio.h>
int main(){
//*/
printf("Actually I am in Nested Comment!!");
//*
return 0;}
/*/
  printf("Am I Printing?");return 0;}
//*/
