//To check for structure syntax
#include<stdio.h>
struct node {
	int x;
	int *y;
};void main() {
struct node n;
}
