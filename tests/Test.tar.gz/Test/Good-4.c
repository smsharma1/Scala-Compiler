//Good testcase - Syntax check for nested - if else
#include<stdio.h>
void main(){
int a = 0;
	if(a == 0){
    		printf("if");
    			if(a > b){
        				printf("nested if");
    			}else{
        				printf(" nested else");
    			}
		}
}
