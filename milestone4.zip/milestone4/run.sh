python irparser.py ThreeAddressCode.txt
nasm -f elf asmfile
gcc -m32 -o nesmex asmfile.o
./nesmex 

